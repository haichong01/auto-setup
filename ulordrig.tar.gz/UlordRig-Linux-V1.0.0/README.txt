操作说明：输入命令./ulordrig开始挖矿,注意：将config.json文件中钱包地址改为自己的钱包地址。
          输入命令./ulordrig -h查看帮助说明。

Instructions: Enter the command ./ulordrig  to begin mining,Note: Change the wallet address in the config.json file to your wallet address.
              Enter the command ./ulordrig -h  to see help instructions.
